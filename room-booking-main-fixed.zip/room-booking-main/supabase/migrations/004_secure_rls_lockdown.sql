-- ========================================================
-- 004_secure_rls_lockdown.sql
-- SECURITY FIX: close the public data-exposure hole.
--
-- BEFORE this migration, several policies used `USING (TRUE)`,
-- `WITH CHECK (TRUE)`, or `has_permission(...) OR TRUE`, and
-- schema.sql additionally created blanket
-- "Allow all for X" ... FOR ALL USING (TRUE) WITH CHECK (TRUE)
-- policies on every table. Because Postgres RLS policies are
-- OR'd together, ANY one permissive policy on a table is enough
-- to expose it — so these effectively disabled RLS entirely on
-- customers, bookings, payments, receipts, etc. Anyone holding
-- the public anon key (shipped to every browser) could read or
-- write that data directly via the Supabase REST API, bypassing
-- the Next.js app and its own permission checks completely.
--
-- The app itself never needs this: every route in app/api/*
-- uses the service-role client (getAdminClient()), which
-- bypasses RLS by design. So sensitive tables can be locked
-- down to service-role-only with zero impact on functionality.
--
-- This migration is idempotent — safe to run multiple times.
-- Run it once in the Supabase SQL Editor for this project.
-- ========================================================

-- ---------------------------------------------------------------
-- 1. Drop every known permissive/insecure policy, from both
--    schema.sql's blanket "Allow all for X" policies and the
--    "OR TRUE" backdoors in 002_rls_and_security.sql, plus the
--    plain USING(TRUE)/WITH CHECK(TRUE) ones. DROP ... IF EXISTS
--    is a no-op if a given name was never created on this project.
-- ---------------------------------------------------------------
DO $$
BEGIN
  -- schema.sql blanket policies
  DROP POLICY IF EXISTS "Allow all for settings" ON settings;
  DROP POLICY IF EXISTS "Allow all for room_types" ON room_types;
  DROP POLICY IF EXISTS "Allow all for rooms" ON rooms;
  DROP POLICY IF EXISTS "Allow all for room_images" ON room_images;
  DROP POLICY IF EXISTS "Allow all for promotions" ON promotions;
  DROP POLICY IF EXISTS "Allow all for permissions" ON permissions;
  DROP POLICY IF EXISTS "Allow all for role_permissions" ON role_permissions;
  DROP POLICY IF EXISTS "Allow all for profiles" ON profiles;
  DROP POLICY IF EXISTS "Allow all for customers" ON customers;
  DROP POLICY IF EXISTS "Allow all for line_users" ON line_users;
  DROP POLICY IF EXISTS "Allow all for bookings" ON bookings;
  DROP POLICY IF EXISTS "Allow all for booking_items" ON booking_items;
  DROP POLICY IF EXISTS "Allow all for booking_discounts" ON booking_discounts;
  DROP POLICY IF EXISTS "Allow all for payments" ON payments;
  DROP POLICY IF EXISTS "Allow all for receipts" ON receipts;
  DROP POLICY IF EXISTS "Allow all for receipt_items" ON receipt_items;
  DROP POLICY IF EXISTS "Allow all for audit_logs" ON audit_logs;

  -- 002_rls_and_security.sql insecure / OR-TRUE policies
  DROP POLICY IF EXISTS "Public can insert customer" ON customers;
  DROP POLICY IF EXISTS "Customers view own or admin" ON customers;
  DROP POLICY IF EXISTS "Admin can manage customers" ON customers;
  DROP POLICY IF EXISTS "Public can insert line user" ON line_users;
  DROP POLICY IF EXISTS "Line user view own or admin" ON line_users;
  DROP POLICY IF EXISTS "Allow booking creation" ON bookings;
  DROP POLICY IF EXISTS "Customer or admin view bookings" ON bookings;
  DROP POLICY IF EXISTS "Admin can update bookings" ON bookings;
  DROP POLICY IF EXISTS "Allow booking items insert" ON booking_items;
  DROP POLICY IF EXISTS "View booking items" ON booking_items;
  DROP POLICY IF EXISTS "View booking discounts" ON booking_discounts;
  DROP POLICY IF EXISTS "Admin manage discounts" ON booking_discounts;
  DROP POLICY IF EXISTS "Allow payment insertion" ON payments;
  DROP POLICY IF EXISTS "View payments" ON payments;
  DROP POLICY IF EXISTS "Admin verify payments" ON payments;
  DROP POLICY IF EXISTS "View receipts" ON receipts;
  DROP POLICY IF EXISTS "Only authorized staff can issue receipts" ON receipts;
  DROP POLICY IF EXISTS "Only authorized staff can cancel receipts" ON receipts;
  DROP POLICY IF EXISTS "View receipt items" ON receipt_items;
  DROP POLICY IF EXISTS "Insert receipt items" ON receipt_items;
  DROP POLICY IF EXISTS "System insert audit logs" ON audit_logs;
END $$;

-- ---------------------------------------------------------------
-- 2. Recreate PUBLIC READ-ONLY policies for genuinely public,
--    non-sensitive browsing content (resort info, room listings,
--    active promotions). No public writes — the admin app writes
--    these via the service-role key, which bypasses RLS anyway.
-- ---------------------------------------------------------------
DROP POLICY IF EXISTS "Public can view resort settings" ON settings;
CREATE POLICY "Public can view resort settings" ON settings
    FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "Admin can update settings" ON settings;
CREATE POLICY "Admin can update settings" ON settings
    FOR ALL USING (has_permission('settings.manage'));

DROP POLICY IF EXISTS "Public can view active room types" ON room_types;
CREATE POLICY "Public can view active room types" ON room_types
    FOR SELECT USING (is_active = TRUE OR has_permission('room.manage'));

DROP POLICY IF EXISTS "Admin can manage room types" ON room_types;
CREATE POLICY "Admin can manage room types" ON room_types
    FOR ALL USING (has_permission('room.manage'));

DROP POLICY IF EXISTS "Public can view rooms" ON rooms;
CREATE POLICY "Public can view rooms" ON rooms
    FOR SELECT USING (status != 'maintenance' OR has_permission('room.manage'));

DROP POLICY IF EXISTS "Admin can manage rooms" ON rooms;
CREATE POLICY "Admin can manage rooms" ON rooms
    FOR ALL USING (has_permission('room.manage'));

DROP POLICY IF EXISTS "Public can view room images" ON room_images;
CREATE POLICY "Public can view room images" ON room_images
    FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "Admin can manage room images" ON room_images;
CREATE POLICY "Admin can manage room images" ON room_images
    FOR ALL USING (has_permission('room.manage'));

DROP POLICY IF EXISTS "Public can view active promotions" ON promotions;
CREATE POLICY "Public can view active promotions" ON promotions
    FOR SELECT USING (is_active = TRUE AND end_date >= CURRENT_DATE);

DROP POLICY IF EXISTS "Admin can manage promotions" ON promotions;
CREATE POLICY "Admin can manage promotions" ON promotions
    FOR ALL USING (has_permission('promotion.manage'));

DROP POLICY IF EXISTS "Public can view permissions" ON permissions;
CREATE POLICY "Public can view permissions" ON permissions
    FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "Public can view role permissions" ON role_permissions;
CREATE POLICY "Public can view role permissions" ON role_permissions
    FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "Profiles self view or admin" ON profiles;
CREATE POLICY "Profiles self view or admin" ON profiles
    FOR SELECT USING (auth_user_id = auth.uid() OR has_permission('user.manage'));

DROP POLICY IF EXISTS "Admin can manage profiles" ON profiles;
CREATE POLICY "Admin can manage profiles" ON profiles
    FOR ALL USING (has_permission('user.manage') OR get_auth_role() = 'OWNER');

-- ---------------------------------------------------------------
-- 3. Sensitive / transactional tables: NO public access at all.
--    Only has_permission()-gated access remains, which always
--    evaluates FALSE for the anon key (no auth.uid() session),
--    so these tables are now unreadable/unwritable from outside
--    the app. The Next.js API (service role) is unaffected since
--    service_role bypasses RLS.
-- ---------------------------------------------------------------
CREATE POLICY "Admin can view customers" ON customers
    FOR SELECT USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can manage customers" ON customers
    FOR ALL USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can manage line users" ON line_users
    FOR ALL USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view bookings" ON bookings
    FOR SELECT USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can create bookings" ON bookings
    FOR INSERT WITH CHECK (has_permission('booking.create') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can update bookings" ON bookings
    FOR UPDATE USING (has_permission('booking.edit') OR has_permission('booking.cancel') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view booking items" ON booking_items
    FOR SELECT USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can insert booking items" ON booking_items
    FOR INSERT WITH CHECK (has_permission('booking.create') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view booking discounts" ON booking_discounts
    FOR SELECT USING (has_permission('booking.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin manage discounts" ON booking_discounts
    FOR ALL USING (has_permission('discount.manage') OR has_permission('booking.create') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view payments" ON payments
    FOR SELECT USING (has_permission('payment.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can insert payments" ON payments
    FOR INSERT WITH CHECK (has_permission('booking.create') OR has_permission('payment.verify') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin verify payments" ON payments
    FOR UPDATE USING (has_permission('payment.verify') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view receipts" ON receipts
    FOR SELECT USING (has_permission('receipt.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Only authorized staff can issue receipts" ON receipts
    FOR INSERT WITH CHECK (has_permission('receipt.create') OR get_auth_role() = 'OWNER');
CREATE POLICY "Only authorized staff can cancel receipts" ON receipts
    FOR UPDATE USING (has_permission('receipt.cancel') OR get_auth_role() = 'OWNER');

CREATE POLICY "Admin can view receipt items" ON receipt_items
    FOR SELECT USING (has_permission('receipt.view') OR get_auth_role() = 'OWNER');
CREATE POLICY "Admin can insert receipt items" ON receipt_items
    FOR INSERT WITH CHECK (has_permission('receipt.create') OR get_auth_role() = 'OWNER');

-- Audit logs: viewing stays as-is (already permission-gated).
-- Inserting no longer needs a public policy — the app writes
-- audit rows through the service-role client, which bypasses RLS.
-- (No replacement INSERT policy is created on purpose: this makes
-- audit_logs INSERT unreachable from anon/authenticated.)
