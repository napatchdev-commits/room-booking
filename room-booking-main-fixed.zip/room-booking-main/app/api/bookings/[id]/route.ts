import { NextRequest, NextResponse } from 'next/server';
import { getAdminClient } from '@/lib/supabase/admin';
import { logAuditEvent } from '@/lib/audit';
import { calculateNights } from '@/lib/formatters';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    if (!id || id === 'undefined' || id === 'null') {
      return NextResponse.json({ error: 'Invalid booking identifier' }, { status: 400 });
    }

    const supabase = getAdminClient();
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

    let query = supabase
      .from('bookings')
      .select(`
        *,
        customer:customers(*),
        booking_items(*, room:rooms(*, room_images(*))),
        booking_discounts(*),
        payments(*),
        receipts(*)
      `);

    if (isUuid) {
      query = query.eq('id', id);
    } else {
      query = query.eq('booking_number', id);
    }

    const { data: booking, error } = await query.maybeSingle();

    if (error) {
      console.error('Booking fetch error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    if (!booking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    return NextResponse.json(
      { success: true, booking },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (error) {
    console.error('Booking GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const body = await req.json();
    const {
      status,
      notes,
      actorId,
      actorName,
      // Stay details
      checkInDate,
      checkOutDate,
      numGuests,
      // Guest details (edits the linked customer record, does NOT create a new one)
      customerName,
      customerPhone,
      customerEmail,
      customerTaxId,
    } = body;

    const supabase = getAdminClient();

    const { data: before } = await supabase
      .from('bookings')
      .select('*, customer:customers(*), booking_items(*)')
      .eq('id', id)
      .single();
    if (!before) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    const updatePayload: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (status) updatePayload.status = status;
    if (notes !== undefined) updatePayload.notes = notes;
    if (numGuests !== undefined) updatePayload.num_guests = Number(numGuests) || 1;

    // Editing stay dates: validate + recalc nights + re-run collision check
    // (excluding this booking itself) against the room(s) already on this booking.
    const nextCheckIn = checkInDate || before.check_in_date;
    const nextCheckOut = checkOutDate || before.check_out_date;
    const datesChanged = nextCheckIn !== before.check_in_date || nextCheckOut !== before.check_out_date;

    if (datesChanged) {
      const totalNights = calculateNights(nextCheckIn, nextCheckOut);
      if (totalNights <= 0) {
        return NextResponse.json({ error: 'Check-out date must be strictly after Check-in date' }, { status: 400 });
      }

      const roomIds = (before.booking_items || []).map((item: any) => item.room_id).filter(Boolean);
      for (const roomId of roomIds) {
        const { data: conflicts, error: conflictErr } = await supabase
          .from('bookings')
          .select('id, booking_items!inner(room_id)')
          .eq('booking_items.room_id', roomId)
          .neq('id', id)
          .in('status', ['PENDING', 'CONFIRMED', 'CHECKED_IN'])
          .lt('check_in_date', nextCheckOut)
          .gt('check_out_date', nextCheckIn);

        if (conflictErr) {
          console.error('Collision check query error:', conflictErr);
          return NextResponse.json({ error: 'Failed to verify room availability' }, { status: 500 });
        }
        if (conflicts && conflicts.length > 0) {
          return NextResponse.json(
            { error: `ห้องนี้ถูกจองเต็มแล้วสำหรับช่วงวันที่เลือก (${nextCheckIn} ถึง ${nextCheckOut})` },
            { status: 409 }
          );
        }
      }

      updatePayload.check_in_date = nextCheckIn;
      updatePayload.check_out_date = nextCheckOut;
      updatePayload.total_nights = totalNights;
    }

    const { data: updated, error } = await supabase
      .from('bookings')
      .update(updatePayload)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // Editing guest info updates the linked customer record directly — it never
    // creates or re-matches a different customer, so this can't cause the
    // "all bookings show the same name" collision that the walk-in default did.
    let updatedCustomer: any = before.customer || null;
    const hasGuestEdit =
      customerName !== undefined ||
      customerPhone !== undefined ||
      customerEmail !== undefined ||
      customerTaxId !== undefined;

    if (hasGuestEdit && before.customer_id) {
      const customerUpdatePayload: Record<string, unknown> = { updated_at: new Date().toISOString() };
      if (customerName !== undefined && String(customerName).trim()) {
        customerUpdatePayload.full_name = String(customerName).trim();
      }
      if (customerPhone !== undefined) {
        customerUpdatePayload.phone = String(customerPhone).trim();
      }
      if (customerEmail !== undefined) {
        customerUpdatePayload.email = String(customerEmail).trim() || null;
      }
      if (customerTaxId !== undefined) {
        customerUpdatePayload.id_card = String(customerTaxId).trim() || null;
      }

      const { data: custUpdated, error: custErr } = await supabase
        .from('customers')
        .update(customerUpdatePayload)
        .eq('id', before.customer_id)
        .select()
        .single();

      if (custErr) {
        return NextResponse.json({ error: custErr.message }, { status: 500 });
      }
      updatedCustomer = custUpdated;
    }

    await logAuditEvent({
      actorId,
      actorName,
      action: status === 'CANCELLED' ? 'BOOKING_CANCEL' : 'BOOKING_EDIT',
      entity: 'booking',
      entityId: id,
      detailsBefore: before,
      detailsAfter: { ...updated, customer: updatedCustomer },
    });

    return NextResponse.json({ success: true, booking: { ...updated, customer: updatedCustomer } });
  } catch (error) {
    console.error('Booking PATCH error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(req.url);
    const actorName = searchParams.get('actorName') || 'Admin';

    const supabase = getAdminClient();

    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
    let query = supabase.from('bookings').select('*, booking_items(*)');
    if (isUuid) query = query.eq('id', id);
    else query = query.eq('booking_number', id);

    const { data: booking } = await query.maybeSingle();
    if (!booking) {
      return NextResponse.json({ error: 'ไม่พบรายการจองนี้' }, { status: 404 });
    }

    const bookingId = booking.id;

    // 1. Delete associated receipts
    await supabase.from('receipts').delete().eq('booking_id', bookingId);

    // 2. Delete associated payments
    await supabase.from('payments').delete().eq('booking_id', bookingId);

    // 3. Delete associated booking discounts
    await supabase.from('booking_discounts').delete().eq('booking_id', bookingId);

    // 4. Delete associated booking items
    await supabase.from('booking_items').delete().eq('booking_id', bookingId);

    // 5. Delete the main booking
    const { error: bErr } = await supabase.from('bookings').delete().eq('id', bookingId);
    if (bErr) {
      return NextResponse.json({ error: bErr.message }, { status: 500 });
    }

    await logAuditEvent({
      actorName,
      action: 'BOOKING_DELETE',
      entity: 'booking',
      entityId: bookingId,
      detailsBefore: booking,
    });

    return NextResponse.json({ success: true, message: 'ลบรายการจองเรียบร้อยแล้ว' });
  } catch (error: any) {
    console.error('Booking DELETE error:', error);
    return NextResponse.json({ error: error.message || 'Internal server error' }, { status: 500 });
  }
}

